line1=Opcje konfiguracyjne,11
display=Tryb wyświetlania użytkowników i grup,1,1-Tylko nazwy,0-Nazwy i moduły
order=Porządkuj użytkowników i grupy wg,1,0-Kolejności w zbiorze,1-Nazwy
line2=Konfiguracja systemu,11
ssleay=Ścieżka do programu openssl lub ssleay,0
