line1=Možnosti konfigurace,11
display=Mód pro zobrazení uživatele a skupiny,1,1-Pouze jména,0-Jména a moduly
order=Třídit uživatele a skupiny podle,1,0-pořadí v souboru,1-jména
line2=Konfigurace systému,11
ssleay=Cesta k programu openssl nebo ssleay,0
