desc_cs=Manualové stránky
