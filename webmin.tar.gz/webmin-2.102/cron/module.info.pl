desc_pl=Harmonogram zadań Cron
longdesc_pl=Twórz, edytuj i usuwaj zadania Cron.
