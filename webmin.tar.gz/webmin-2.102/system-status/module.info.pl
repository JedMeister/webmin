desc_pl=Stan systemu
longdesc_pl=Biblioteki zbierania danych o stanu systemu w tle
